package com.javalab.board.service;

import com.javalab.board.vo.MemberVo;

public interface LoginService {

	public MemberVo login(MemberVo memberVo);
}