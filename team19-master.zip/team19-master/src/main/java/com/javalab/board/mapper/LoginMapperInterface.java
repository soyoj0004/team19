package com.javalab.board.mapper;

import com.javalab.board.vo.MemberVo;

public interface LoginMapperInterface {

	public MemberVo login(MemberVo memberVo);
}