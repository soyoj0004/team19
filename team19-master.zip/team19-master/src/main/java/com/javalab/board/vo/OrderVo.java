package com.javalab.board.vo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * OrderVo 자바빈즈 클래스
 * - JSP, Servlet 간의 데이터 이동시 사용
 * - private 멤버변수, 게터/세터, 기본생성자
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class OrderVo {
    private int orderId;
    private String memberId;
    private int totalPrice;
    private Date orderDate;
    private String orderName;
    private String status;
    private String addr;
    private String addrDetail;
    private String phone;
    private int itemCnt;
    private String itemName;
    private String itemImg;
}
